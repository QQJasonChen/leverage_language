// Audio Permission Handler
// This page handles microphone permission requests for the extension

document.addEventListener('DOMContentLoaded', () => {
  const requestBtn = document.getElementById('requestPermission');
  const statusDiv = document.getElementById('status');

  function showStatus(message, type) {
    statusDiv.textContent = message;
    statusDiv.className = `status ${type}`;
    statusDiv.style.display = 'block';
  }

  requestBtn.addEventListener('click', async () => {
    requestBtn.disabled = true;
    requestBtn.textContent = 'Requesting...';
    showStatus('Requesting microphone access...', 'info');

    try {
      // Request microphone permission
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true
        }
      });

      // Permission granted! Stop the stream immediately
      stream.getTracks().forEach(track => track.stop());

      showStatus('Microphone permission granted! You can close this window.', 'success');
      requestBtn.textContent = 'Permission Granted';

      // Notify the parent window/extension
      if (window.opener) {
        window.opener.postMessage({ type: 'MICROPHONE_PERMISSION_GRANTED' }, '*');
      }

      // Also try to communicate via chrome runtime
      try {
        chrome.runtime.sendMessage({ type: 'MICROPHONE_PERMISSION_GRANTED' });
      } catch (e) {
        console.log('Could not send message to extension:', e);
      }

      // Auto-close after 2 seconds
      setTimeout(() => {
        window.close();
      }, 2000);

    } catch (error) {
      console.error('Microphone permission error:', error);

      let errorMessage = 'Failed to get microphone permission.';
      if (error.name === 'NotAllowedError') {
        errorMessage = 'Permission denied. Please click "Allow" when the browser asks for microphone access.';
      } else if (error.name === 'NotFoundError') {
        errorMessage = 'No microphone found. Please connect a microphone and try again.';
      } else if (error.name === 'NotReadableError') {
        errorMessage = 'Microphone is being used by another application.';
      }

      showStatus(errorMessage, 'error');
      requestBtn.disabled = false;
      requestBtn.textContent = 'Try Again';
    }
  });

  // Check current permission status
  async function checkPermissionStatus() {
    try {
      if (navigator.permissions) {
        const result = await navigator.permissions.query({ name: 'microphone' });
        if (result.state === 'granted') {
          showStatus('Microphone permission already granted!', 'success');
          requestBtn.textContent = 'Already Granted';

          // Auto-close
          setTimeout(() => {
            window.close();
          }, 1500);
        } else if (result.state === 'denied') {
          showStatus('Permission was previously denied. Please reset it in browser settings.', 'error');
        }
      }
    } catch (e) {
      console.log('Permission API not available:', e);
    }
  }

  checkPermissionStatus();
});
