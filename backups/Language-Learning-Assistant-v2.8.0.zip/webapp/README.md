# 語言學習助手 - 口說練習網頁版

這是一個獨立的口說練習網頁應用，與 Language Learning Assistant Chrome 擴充功能無縫整合。

## 功能特色

- **Google 帳號登入** - 與 Chrome 擴充功能共享登入狀態
- **雲端同步** - 自動從 Google Drive 載入你的詞彙卡片
- **高品質 TTS** - 使用 OpenAI TTS-1-HD 播放標準發音
- **AI 發音評估** - Whisper 語音識別 + GPT 智慧評分
- **響應式設計** - 支援電腦、平板、手機

## 部署到 GitHub Pages

### 步驟 1：設定 Google Cloud Console

1. 前往 [Google Cloud Console](https://console.cloud.google.com/)
2. 選擇你的專案（與 Chrome 擴充功能相同的專案）
3. 前往「API 和服務」→「憑證」
4. 找到 OAuth 2.0 用戶端 ID
5. 在「已授權的 JavaScript 來源」中添加：
   ```
   https://qqjasonchen.github.io
   ```
6. 儲存變更

### 步驟 2：部署到 GitHub Pages

**方法 A：使用現有 Repository**

1. 將 `webapp/` 目錄推送到你的 GitHub repository

2. 前往 Repository Settings → Pages

3. Source 選擇 `main` 分支，目錄選擇 `/webapp`

4. 儲存後等待幾分鐘，網站會在以下網址可用：
   ```
   https://qqjasonchen.github.io/[repo-name]/
   ```

**方法 B：創建新 Repository**

1. 在 GitHub 創建新 repository（例如：`language-learning-webapp`）

2. Clone 並複製 webapp 文件：
   ```bash
   git clone https://github.com/QQJasonChen/language-learning-webapp.git
   cd language-learning-webapp
   cp -r /path/to/webapp/* .
   git add .
   git commit -m "Initial commit"
   git push
   ```

3. 啟用 GitHub Pages（Settings → Pages → Source: main branch）

4. 網站會在以下網址可用：
   ```
   https://qqjasonchen.github.io/language-learning-webapp/
   ```

## 本機測試

由於使用 Google OAuth，需要透過 HTTPS 或 localhost 測試：

```bash
# 方法 1：使用 Python HTTP Server
cd webapp
python -m http.server 8000
# 然後在瀏覽器開啟 http://localhost:8000

# 方法 2：使用 VS Code Live Server 擴充功能
# 右鍵點擊 index.html → Open with Live Server
```

**注意**：本機測試時需要在 Google Cloud Console 添加 `http://localhost:8000` 為授權來源。

## 檔案結構

```
webapp/
├── index.html          # 主頁面
├── css/
│   └── style.css       # 樣式表（橘色主題）
├── js/
│   ├── app.js          # 應用主邏輯
│   ├── auth.js         # Google OAuth 認證
│   ├── drive-api.js    # Google Drive API
│   ├── speaking.js     # 口說練習邏輯
│   └── tts-service.js  # TTS 和 Whisper 服務
└── README.md           # 本文件
```

## 使用方式

1. **登入**
   - 點擊「使用 Google 登入」
   - 使用與 Chrome 擴充功能相同的 Google 帳號

2. **開始練習**
   - 登入後點擊「開始練習」
   - 系統會從 Google Drive 載入你的詞彙卡片

3. **練習流程**
   - 點擊「聽標準發音」聆聽正確發音
   - 點擊「開始錄音」錄製你的發音
   - 系統會自動評估並給出分數和建議

4. **設定 API Key（可選）**
   - 點擊右上角齒輪圖示
   - 輸入 OpenAI API Key 以啟用高品質 TTS 和 AI 評估
   - 不設定也可使用瀏覽器內建 TTS（品質較低）

## 技術架構

- **認證**：Google Identity Services (GIS)
- **數據**：Google Drive API (appDataFolder)
- **TTS**：OpenAI TTS-1-HD / 瀏覽器 Speech Synthesis
- **語音識別**：OpenAI Whisper API
- **評估**：OpenAI GPT-4o-mini

## 常見問題

### Q: 為什麼看不到我的詞彙卡片？

A: 請確保：
1. 使用與 Chrome 擴充功能相同的 Google 帳號登入
2. 在擴充功能中已啟用 Google Drive 同步
3. 擴充功能中至少有一張詞彙卡片

### Q: 麥克風無法使用？

A: 請確保：
1. 瀏覽器已授權麥克風權限
2. 使用 HTTPS 或 localhost 訪問網頁
3. 沒有其他應用程式佔用麥克風

### Q: API Key 安全嗎？

A: API Key 僅儲存在你的瀏覽器 localStorage 中，不會傳送到任何第三方伺服器。所有 API 請求都直接從你的瀏覽器發送到 OpenAI。

## 授權

MIT License

## 聯絡

GitHub: [@QQJasonChen](https://github.com/QQJasonChen)
