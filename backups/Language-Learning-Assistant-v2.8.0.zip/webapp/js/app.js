/**
 * Main Application Module
 * Handles app initialization and UI management
 */

const App = {
  // State
  isInitialized: false,
  currentView: 'login', // 'login', 'practice', 'settings'

  /**
   * Initialize application
   */
  async init() {
    console.log('🚀 Initializing Language Learning Webapp...');

    // Initialize services
    TTSService.init();

    // Setup auth callbacks
    AuthService.onLogin((user, token) => {
      console.log('✅ User logged in:', user.email);
      this.onUserLogin(user);
    });

    AuthService.onLogout(() => {
      console.log('👋 User logged out');
      this.onUserLogout();
    });

    AuthService.onError((error) => {
      console.error('❌ Auth error:', error);
      this.showMessage('登入錯誤: ' + error, 'error');
    });

    // Initialize auth
    try {
      await AuthService.init();

      // Check if already authenticated
      if (AuthService.isAuthenticated()) {
        const user = AuthService.getUser();
        if (user) {
          this.onUserLogin(user);
        }
      }
    } catch (error) {
      console.error('Auth init error:', error);
    }

    // Initialize UI
    this.initUI();

    // Check for API key
    this.checkApiKey();

    this.isInitialized = true;
    console.log('✅ App initialized');
  },

  /**
   * Initialize UI elements
   */
  initUI() {
    // Login button
    document.getElementById('loginBtn')?.addEventListener('click', () => {
      AuthService.signIn();
    });

    // Logout button
    document.getElementById('logoutBtn')?.addEventListener('click', () => {
      this.logout();
    });

    // Settings button
    document.getElementById('settingsBtn')?.addEventListener('click', () => {
      this.showSettings();
    });

    // Close settings button
    document.getElementById('closeSettingsBtn')?.addEventListener('click', () => {
      this.hideSettings();
    });

    // Save API key button
    document.getElementById('saveApiKeyBtn')?.addEventListener('click', () => {
      this.saveApiKey();
    });

    // Start practice button
    document.getElementById('startPracticeBtn')?.addEventListener('click', () => {
      this.startPractice();
    });

    // Voice selector
    document.getElementById('voiceSelect')?.addEventListener('change', (e) => {
      TTSService.setVoice(e.target.value);
      this.showMessage('已更換語音', 'success');
    });

    // Initialize voice selector
    this.initVoiceSelector();
  },

  /**
   * Initialize voice selector
   */
  initVoiceSelector() {
    const select = document.getElementById('voiceSelect');
    if (!select) return;

    // Clear existing options
    select.innerHTML = '';

    // Add voice options
    Object.entries(TTSService.voices).forEach(([value, label]) => {
      const option = document.createElement('option');
      option.value = value;
      option.textContent = label;
      if (value === TTSService.defaultVoice) {
        option.selected = true;
      }
      select.appendChild(option);
    });
  },

  /**
   * Handle user login
   */
  async onUserLogin(user) {
    // Update UI
    this.showView('practice');

    // Update user info
    const userNameEl = document.getElementById('userName');
    const userEmailEl = document.getElementById('userEmail');
    const userAvatarEl = document.getElementById('userAvatar');

    if (userNameEl) userNameEl.textContent = user.name || '';
    if (userEmailEl) userEmailEl.textContent = user.email || '';
    if (userAvatarEl && user.picture) {
      userAvatarEl.src = user.picture;
      userAvatarEl.style.display = 'block';
    }

    // Initialize speaking practice
    await SpeakingPractice.init();
  },

  /**
   * Handle user logout
   */
  onUserLogout() {
    this.showView('login');

    // Save session stats before logout
    SpeakingPractice.saveSessionStats();
  },

  /**
   * Logout user
   */
  logout() {
    // Save stats first
    SpeakingPractice.saveSessionStats();

    // Sign out
    AuthService.signOut();
  },

  /**
   * Start speaking practice
   */
  async startPractice() {
    const success = await SpeakingPractice.loadCards();
    if (success) {
      document.getElementById('welcomeSection')?.classList.add('hidden');
      document.getElementById('practiceSection')?.classList.remove('hidden');
    }
  },

  /**
   * Show view
   */
  showView(view) {
    this.currentView = view;

    const loginView = document.getElementById('loginView');
    const mainView = document.getElementById('mainView');

    if (view === 'login') {
      loginView?.classList.remove('hidden');
      mainView?.classList.add('hidden');
    } else {
      loginView?.classList.add('hidden');
      mainView?.classList.remove('hidden');
    }
  },

  /**
   * Show settings modal
   */
  showSettings() {
    const modal = document.getElementById('settingsModal');
    if (modal) {
      modal.classList.remove('hidden');

      // Load current API key (masked)
      const apiKeyInput = document.getElementById('apiKeyInput');
      if (apiKeyInput && TTSService.getApiKey()) {
        apiKeyInput.value = '••••••••••••••••';
        apiKeyInput.dataset.hasKey = 'true';
      }
    }
  },

  /**
   * Hide settings modal
   */
  hideSettings() {
    const modal = document.getElementById('settingsModal');
    if (modal) {
      modal.classList.add('hidden');
    }
  },

  /**
   * Save API key
   */
  saveApiKey() {
    const input = document.getElementById('apiKeyInput');
    if (!input) return;

    const apiKey = input.value.trim();

    // Check if it's the masked placeholder
    if (apiKey === '••••••••••••••••') {
      this.hideSettings();
      return;
    }

    if (apiKey && apiKey.startsWith('sk-')) {
      TTSService.setApiKey(apiKey);
      this.showMessage('API Key 已儲存', 'success');
      this.hideSettings();
      this.updateApiKeyStatus();
    } else if (apiKey === '') {
      // Clear API key
      localStorage.removeItem('openai_api_key');
      TTSService.apiKey = null;
      this.showMessage('API Key 已清除', 'info');
      this.hideSettings();
      this.updateApiKeyStatus();
    } else {
      this.showMessage('請輸入有效的 OpenAI API Key（以 sk- 開頭）', 'error');
    }
  },

  /**
   * Check API key status
   */
  checkApiKey() {
    this.updateApiKeyStatus();
  },

  /**
   * Update API key status indicator
   */
  updateApiKeyStatus() {
    const statusEl = document.getElementById('apiKeyStatus');
    if (!statusEl) return;

    if (TTSService.isAvailable()) {
      statusEl.innerHTML = '<span class="status-badge status-active">✓ AI 功能已啟用</span>';
    } else {
      statusEl.innerHTML = '<span class="status-badge status-inactive">○ 未設定 API Key</span>';
    }
  },

  /**
   * Show loading overlay
   */
  showLoading(message = '載入中...') {
    let overlay = document.getElementById('loadingOverlay');

    if (!overlay) {
      overlay = document.createElement('div');
      overlay.id = 'loadingOverlay';
      overlay.className = 'loading-overlay';
      overlay.innerHTML = `
        <div class="loading-content">
          <div class="loading-spinner"></div>
          <p class="loading-message">${message}</p>
        </div>
      `;
      document.body.appendChild(overlay);
    } else {
      const msgEl = overlay.querySelector('.loading-message');
      if (msgEl) msgEl.textContent = message;
      overlay.classList.remove('hidden');
    }
  },

  /**
   * Hide loading overlay
   */
  hideLoading() {
    const overlay = document.getElementById('loadingOverlay');
    if (overlay) {
      overlay.classList.add('hidden');
    }
  },

  /**
   * Show message toast
   */
  showMessage(message, type = 'info') {
    // Remove existing toast
    const existingToast = document.querySelector('.toast-message');
    if (existingToast) {
      existingToast.remove();
    }

    // Create toast
    const toast = document.createElement('div');
    toast.className = `toast-message toast-${type}`;
    toast.textContent = message;

    document.body.appendChild(toast);

    // Show toast
    setTimeout(() => toast.classList.add('show'), 10);

    // Hide after 3 seconds
    setTimeout(() => {
      toast.classList.remove('show');
      setTimeout(() => toast.remove(), 300);
    }, 3000);
  }
};

// Initialize app when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
  // Wait for Google Identity Services to load
  const checkGIS = setInterval(() => {
    if (typeof google !== 'undefined' && google.accounts) {
      clearInterval(checkGIS);
      App.init();
    }
  }, 100);

  // Timeout after 10 seconds
  setTimeout(() => {
    clearInterval(checkGIS);
    if (!App.isInitialized) {
      console.error('Failed to load Google Identity Services');
      App.showMessage('無法載入 Google 登入服務，請重新整理頁面', 'error');
    }
  }, 10000);
});

// Handle page unload
window.addEventListener('beforeunload', () => {
  SpeakingPractice.saveSessionStats();
});

// Export for use
window.App = App;
