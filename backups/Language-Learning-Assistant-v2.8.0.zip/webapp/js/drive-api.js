/**
 * Google Drive API Module
 * Handles reading/writing data to Google Drive appDataFolder
 */

const DriveAPI = {
  BASE_URL: 'https://www.googleapis.com/drive/v3',
  UPLOAD_URL: 'https://www.googleapis.com/upload/drive/v3',

  // File names (same as extension)
  FILES: {
    FLASHCARDS: 'language_learning_flashcards.json',
    SETTINGS: 'language_learning_settings.json',
    STATS: 'language_learning_stats.json',
    REPORTS: 'language_learning_reports.json'
  },

  // Cache for file IDs
  fileIdCache: {},

  /**
   * Get authorization header
   */
  getAuthHeader() {
    const token = AuthService.getAccessToken();
    if (!token) {
      throw new Error('Not authenticated');
    }
    return {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    };
  },

  /**
   * List files in appDataFolder
   */
  async listFiles() {
    const response = await fetch(
      `${this.BASE_URL}/files?spaces=appDataFolder&fields=files(id,name,modifiedTime)`,
      { headers: this.getAuthHeader() }
    );

    if (!response.ok) {
      throw new Error(`Failed to list files: ${response.status}`);
    }

    const data = await response.json();

    // Cache file IDs
    if (data.files) {
      data.files.forEach(file => {
        this.fileIdCache[file.name] = file.id;
      });
    }

    return data.files || [];
  },

  /**
   * Get file ID by name
   */
  async getFileId(fileName) {
    // Check cache first
    if (this.fileIdCache[fileName]) {
      return this.fileIdCache[fileName];
    }

    // Search for file
    const response = await fetch(
      `${this.BASE_URL}/files?spaces=appDataFolder&q=name='${fileName}'&fields=files(id,name)`,
      { headers: this.getAuthHeader() }
    );

    if (!response.ok) {
      throw new Error(`Failed to search file: ${response.status}`);
    }

    const data = await response.json();

    if (data.files && data.files.length > 0) {
      this.fileIdCache[fileName] = data.files[0].id;
      return data.files[0].id;
    }

    return null;
  },

  /**
   * Read file content
   */
  async readFile(fileName) {
    const fileId = await this.getFileId(fileName);

    if (!fileId) {
      console.log(`File not found: ${fileName}`);
      return null;
    }

    const response = await fetch(
      `${this.BASE_URL}/files/${fileId}?alt=media`,
      { headers: this.getAuthHeader() }
    );

    if (!response.ok) {
      throw new Error(`Failed to read file: ${response.status}`);
    }

    return response.json();
  },

  /**
   * Write/Update file content
   */
  async writeFile(fileName, content) {
    const fileId = await this.getFileId(fileName);

    if (fileId) {
      // Update existing file
      return this.updateFile(fileId, content);
    } else {
      // Create new file
      return this.createFile(fileName, content);
    }
  },

  /**
   * Create new file
   */
  async createFile(fileName, content) {
    // Create file metadata
    const metadata = {
      name: fileName,
      parents: ['appDataFolder']
    };

    // Create multipart request
    const boundary = 'boundary_' + Date.now();
    const body = [
      `--${boundary}`,
      'Content-Type: application/json; charset=UTF-8',
      '',
      JSON.stringify(metadata),
      `--${boundary}`,
      'Content-Type: application/json',
      '',
      JSON.stringify(content),
      `--${boundary}--`
    ].join('\r\n');

    const response = await fetch(
      `${this.UPLOAD_URL}/files?uploadType=multipart`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${AuthService.getAccessToken()}`,
          'Content-Type': `multipart/related; boundary=${boundary}`
        },
        body: body
      }
    );

    if (!response.ok) {
      throw new Error(`Failed to create file: ${response.status}`);
    }

    const data = await response.json();
    this.fileIdCache[fileName] = data.id;

    return data;
  },

  /**
   * Update existing file
   */
  async updateFile(fileId, content) {
    const response = await fetch(
      `${this.UPLOAD_URL}/files/${fileId}?uploadType=media`,
      {
        method: 'PATCH',
        headers: {
          'Authorization': `Bearer ${AuthService.getAccessToken()}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(content)
      }
    );

    if (!response.ok) {
      throw new Error(`Failed to update file: ${response.status}`);
    }

    return response.json();
  },

  // ==========================================
  // High-level data access methods
  // ==========================================

  /**
   * Get all flashcards
   */
  async getFlashcards() {
    try {
      const data = await this.readFile(this.FILES.FLASHCARDS);
      return data?.flashcards || [];
    } catch (error) {
      console.error('Failed to get flashcards:', error);
      return [];
    }
  },

  /**
   * Save flashcards
   */
  async saveFlashcards(flashcards) {
    const data = {
      flashcards: flashcards,
      lastModified: Date.now(),
      source: 'webapp'
    };

    return this.writeFile(this.FILES.FLASHCARDS, data);
  },

  /**
   * Get user settings
   */
  async getSettings() {
    try {
      return await this.readFile(this.FILES.SETTINGS);
    } catch (error) {
      console.error('Failed to get settings:', error);
      return null;
    }
  },

  /**
   * Save user settings
   */
  async saveSettings(settings) {
    return this.writeFile(this.FILES.SETTINGS, settings);
  },

  /**
   * Get statistics
   */
  async getStats() {
    try {
      return await this.readFile(this.FILES.STATS);
    } catch (error) {
      console.error('Failed to get stats:', error);
      return null;
    }
  },

  /**
   * Save statistics
   */
  async saveStats(stats) {
    return this.writeFile(this.FILES.STATS, stats);
  },

  /**
   * Update speaking practice statistics
   */
  async updateSpeakingStats(practiceData) {
    try {
      let stats = await this.getStats() || {};

      // Initialize speaking stats if not exists
      if (!stats.speakingPractice) {
        stats.speakingPractice = {
          totalSessions: 0,
          totalPracticed: 0,
          averageScore: 0,
          history: []
        };
      }

      // Update stats
      stats.speakingPractice.totalSessions++;
      stats.speakingPractice.totalPracticed += practiceData.cardsCount || 1;
      stats.speakingPractice.history.push({
        date: new Date().toISOString(),
        score: practiceData.score,
        cardsCount: practiceData.cardsCount,
        source: 'webapp'
      });

      // Calculate average
      const scores = stats.speakingPractice.history
        .filter(h => h.score !== undefined)
        .map(h => h.score);
      if (scores.length > 0) {
        stats.speakingPractice.averageScore =
          scores.reduce((a, b) => a + b, 0) / scores.length;
      }

      // Keep only last 100 history entries
      if (stats.speakingPractice.history.length > 100) {
        stats.speakingPractice.history = stats.speakingPractice.history.slice(-100);
      }

      stats.lastModified = Date.now();

      await this.saveStats(stats);

      return stats;
    } catch (error) {
      console.error('Failed to update speaking stats:', error);
      throw error;
    }
  }
};

// Export for use
window.DriveAPI = DriveAPI;
