/**
 * TTS and Whisper Service Module
 * Handles Text-to-Speech and Speech-to-Text using OpenAI APIs
 */

const TTSService = {
  // OpenAI API endpoint
  OPENAI_API_URL: 'https://api.openai.com/v1',

  // API Key (stored in localStorage)
  apiKey: null,

  // Default settings
  defaultVoice: 'alloy',
  defaultModel: 'tts-1-hd',

  // Voice options
  voices: {
    'alloy': 'Alloy (中性)',
    'echo': 'Echo (男聲)',
    'fable': 'Fable (女聲)',
    'onyx': 'Onyx (深沉男聲)',
    'nova': 'Nova (女聲)',
    'shimmer': 'Shimmer (柔和女聲)'
  },

  /**
   * Initialize service
   */
  init() {
    this.apiKey = localStorage.getItem('openai_api_key');
    const savedVoice = localStorage.getItem('tts_voice');
    if (savedVoice) {
      this.defaultVoice = savedVoice;
    }
  },

  /**
   * Set API key
   */
  setApiKey(apiKey) {
    this.apiKey = apiKey;
    localStorage.setItem('openai_api_key', apiKey);
  },

  /**
   * Get API key
   */
  getApiKey() {
    return this.apiKey;
  },

  /**
   * Check if API is available
   */
  isAvailable() {
    return !!this.apiKey;
  },

  /**
   * Set default voice
   */
  setVoice(voice) {
    this.defaultVoice = voice;
    localStorage.setItem('tts_voice', voice);
  },

  /**
   * Generate speech from text using OpenAI TTS
   * @param {string} text - Text to convert to speech
   * @param {string} voice - Voice to use (optional)
   * @param {number} speed - Speed multiplier (0.25-4.0)
   * @returns {Promise<{audioUrl: string, audioBlob: Blob}>}
   */
  async textToSpeech(text, voice = null, speed = 1.0) {
    if (!this.isAvailable()) {
      throw new Error('OpenAI API key not configured');
    }

    const response = await fetch(`${this.OPENAI_API_URL}/audio/speech`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: this.defaultModel,
        input: text,
        voice: voice || this.defaultVoice,
        speed: Math.max(0.25, Math.min(4.0, speed)),
        response_format: 'mp3'
      })
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({}));
      throw new Error(error.error?.message || `TTS failed: ${response.status}`);
    }

    const audioBlob = await response.blob();
    const audioUrl = URL.createObjectURL(audioBlob);

    return { audioUrl, audioBlob };
  },

  /**
   * Transcribe audio using OpenAI Whisper
   * @param {Blob} audioBlob - Audio blob to transcribe
   * @param {string} language - Language code (e.g., 'nl', 'de', 'en')
   * @returns {Promise<{text: string, segments: Array}>}
   */
  async transcribeAudio(audioBlob, language = 'nl') {
    if (!this.isAvailable()) {
      throw new Error('OpenAI API key not configured');
    }

    const formData = new FormData();
    formData.append('file', audioBlob, 'audio.webm');
    formData.append('model', 'whisper-1');
    formData.append('language', language);
    formData.append('response_format', 'verbose_json');

    const response = await fetch(`${this.OPENAI_API_URL}/audio/transcriptions`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.apiKey}`
      },
      body: formData
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({}));
      throw new Error(error.error?.message || `Transcription failed: ${response.status}`);
    }

    const result = await response.json();

    return {
      text: result.text,
      segments: result.segments || [],
      language: result.language,
      duration: result.duration
    };
  },

  /**
   * Evaluate pronunciation using GPT
   * @param {string} targetText - Expected text
   * @param {string} spokenText - What user actually said
   * @param {string} language - Language being practiced
   * @returns {Promise<Object>} Evaluation result
   */
  async evaluatePronunciation(targetText, spokenText, language = 'dutch') {
    if (!this.isAvailable()) {
      throw new Error('OpenAI API key not configured');
    }

    const languageNames = {
      'nl': 'Dutch',
      'de': 'German',
      'en': 'English',
      'dutch': 'Dutch',
      'german': 'German',
      'english': 'English'
    };

    const langName = languageNames[language] || language;

    const prompt = `You are a ${langName} pronunciation coach. Evaluate the learner's pronunciation.

Target sentence: "${targetText}"
What was spoken: "${spokenText}"

Provide evaluation in JSON format:
{
  "accuracy": <number 0-100>,
  "feedback": "<brief feedback in Traditional Chinese>",
  "issues": ["<specific pronunciation issues if any>"],
  "tips": ["<improvement tips in Traditional Chinese>"],
  "encouragement": "<motivational message in Traditional Chinese>"
}

Be encouraging but honest. If the spoken text is very different or empty, give lower accuracy score.`;

    const response = await fetch(`${this.OPENAI_API_URL}/chat/completions`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [
          { role: 'system', content: 'You are a helpful language pronunciation coach. Always respond with valid JSON.' },
          { role: 'user', content: prompt }
        ],
        temperature: 0.7,
        max_tokens: 500
      })
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({}));
      throw new Error(error.error?.message || `Evaluation failed: ${response.status}`);
    }

    const result = await response.json();
    const content = result.choices[0]?.message?.content;

    try {
      // Try to parse JSON from response
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        return JSON.parse(jsonMatch[0]);
      }
      throw new Error('Invalid response format');
    } catch (e) {
      console.warn('Failed to parse evaluation response:', content);
      // Return default evaluation
      return {
        accuracy: spokenText.toLowerCase().trim() === targetText.toLowerCase().trim() ? 100 : 50,
        feedback: '無法完成評估，請再試一次。',
        issues: [],
        tips: ['請確保在安靜的環境中練習'],
        encouragement: '繼續加油！'
      };
    }
  },

  /**
   * Use browser's built-in TTS as fallback
   * @param {string} text - Text to speak
   * @param {string} lang - Language code
   * @param {number} rate - Speaking rate
   */
  speakWithBrowser(text, lang = 'nl-NL', rate = 1.0) {
    return new Promise((resolve, reject) => {
      if (!window.speechSynthesis) {
        reject(new Error('Browser TTS not supported'));
        return;
      }

      // Cancel any ongoing speech
      speechSynthesis.cancel();

      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = lang;
      utterance.rate = rate;
      utterance.pitch = 1.0;

      // Try to find appropriate voice
      const voices = speechSynthesis.getVoices();
      const langPrefix = lang.split('-')[0];
      const targetVoice = voices.find(v => v.lang.startsWith(langPrefix));
      if (targetVoice) {
        utterance.voice = targetVoice;
      }

      utterance.onend = () => resolve();
      utterance.onerror = (e) => reject(e);

      speechSynthesis.speak(utterance);
    });
  }
};

// Export for use
window.TTSService = TTSService;
