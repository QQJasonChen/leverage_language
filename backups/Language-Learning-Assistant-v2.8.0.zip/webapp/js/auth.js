/**
 * Google OAuth Authentication Module
 * Handles Google Sign-In using Google Identity Services (GIS)
 */

const AuthService = {
  // OAuth Configuration
  CLIENT_ID: '761534766844-v48qu2kdnjvpmmp7r4f73h0sojloqo1n.apps.googleusercontent.com',
  SCOPES: [
    'https://www.googleapis.com/auth/userinfo.email',
    'https://www.googleapis.com/auth/userinfo.profile',
    'https://www.googleapis.com/auth/drive.appdata'
  ].join(' '),

  // State
  tokenClient: null,
  accessToken: null,
  user: null,

  /**
   * Initialize Google Identity Services
   */
  init() {
    return new Promise((resolve, reject) => {
      // Check if GIS script is loaded
      if (typeof google === 'undefined' || !google.accounts) {
        reject(new Error('Google Identity Services not loaded'));
        return;
      }

      // Initialize token client
      this.tokenClient = google.accounts.oauth2.initTokenClient({
        client_id: this.CLIENT_ID,
        scope: this.SCOPES,
        callback: (response) => {
          if (response.error) {
            console.error('OAuth error:', response.error);
            this.onAuthError(response.error);
            return;
          }

          this.accessToken = response.access_token;
          this.onAuthSuccess(response.access_token);
        }
      });

      // Check for existing token in localStorage
      const savedToken = localStorage.getItem('google_access_token');
      const tokenExpiry = localStorage.getItem('google_token_expiry');

      if (savedToken && tokenExpiry && Date.now() < parseInt(tokenExpiry)) {
        this.accessToken = savedToken;
        this.validateAndRestoreSession(savedToken).then(resolve).catch(() => {
          // Token invalid, clear and resolve
          this.clearSession();
          resolve();
        });
      } else {
        resolve();
      }
    });
  },

  /**
   * Validate token and restore session
   */
  async validateAndRestoreSession(token) {
    try {
      const userInfo = await this.getUserInfo(token);
      this.user = userInfo;
      this.onSessionRestored(userInfo);
      return userInfo;
    } catch (error) {
      throw error;
    }
  },

  /**
   * Trigger Google Sign-In
   */
  signIn() {
    if (!this.tokenClient) {
      console.error('Token client not initialized');
      return;
    }

    // Request access token
    this.tokenClient.requestAccessToken({ prompt: 'consent' });
  },

  /**
   * Sign out and clear session
   */
  signOut() {
    if (this.accessToken) {
      // Revoke token
      google.accounts.oauth2.revoke(this.accessToken, () => {
        console.log('Token revoked');
      });
    }

    this.clearSession();
    this.onSignOut();
  },

  /**
   * Clear session data
   */
  clearSession() {
    this.accessToken = null;
    this.user = null;
    localStorage.removeItem('google_access_token');
    localStorage.removeItem('google_token_expiry');
    localStorage.removeItem('google_user');
  },

  /**
   * Handle successful authentication
   */
  async onAuthSuccess(accessToken) {
    try {
      // Save token with 1 hour expiry
      localStorage.setItem('google_access_token', accessToken);
      localStorage.setItem('google_token_expiry', Date.now() + 3600000);

      // Get user info
      const userInfo = await this.getUserInfo(accessToken);
      this.user = userInfo;
      localStorage.setItem('google_user', JSON.stringify(userInfo));

      // Trigger callback
      if (this.onLoginCallback) {
        this.onLoginCallback(userInfo, accessToken);
      }
    } catch (error) {
      console.error('Failed to get user info:', error);
      this.onAuthError(error);
    }
  },

  /**
   * Handle authentication error
   */
  onAuthError(error) {
    if (this.onErrorCallback) {
      this.onErrorCallback(error);
    }
  },

  /**
   * Handle session restored
   */
  onSessionRestored(userInfo) {
    if (this.onLoginCallback) {
      this.onLoginCallback(userInfo, this.accessToken);
    }
  },

  /**
   * Handle sign out
   */
  onSignOut() {
    if (this.onLogoutCallback) {
      this.onLogoutCallback();
    }
  },

  /**
   * Get user info from Google API
   */
  async getUserInfo(accessToken) {
    const response = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
      headers: {
        'Authorization': `Bearer ${accessToken}`
      }
    });

    if (!response.ok) {
      throw new Error('Failed to get user info');
    }

    return response.json();
  },

  /**
   * Get current access token
   */
  getAccessToken() {
    return this.accessToken;
  },

  /**
   * Get current user
   */
  getUser() {
    return this.user;
  },

  /**
   * Check if user is authenticated
   */
  isAuthenticated() {
    return !!this.accessToken;
  },

  /**
   * Set login callback
   */
  onLogin(callback) {
    this.onLoginCallback = callback;
  },

  /**
   * Set logout callback
   */
  onLogout(callback) {
    this.onLogoutCallback = callback;
  },

  /**
   * Set error callback
   */
  onError(callback) {
    this.onErrorCallback = callback;
  }
};

// Export for use
window.AuthService = AuthService;
