/**
 * Speaking Practice Module
 * Core logic for pronunciation practice
 */

const SpeakingPractice = {
  // State
  cards: [],
  currentIndex: 0,
  isRecording: false,
  mediaRecorder: null,
  audioChunks: [],
  currentAudio: null,
  currentLanguage: 'dutch',

  // Practice statistics
  stats: {
    practiced: 0,
    totalScore: 0,
    sessionStart: null
  },

  // Language mapping
  languageMap: {
    'dutch': { code: 'nl', ttsLang: 'nl-NL', name: '荷蘭文' },
    'german': { code: 'de', ttsLang: 'de-DE', name: '德文' },
    'english': { code: 'en', ttsLang: 'en-US', name: '英文' },
    'japanese': { code: 'ja', ttsLang: 'ja-JP', name: '日文' },
    'korean': { code: 'ko', ttsLang: 'ko-KR', name: '韓文' }
  },

  /**
   * Initialize speaking practice
   */
  async init() {
    this.stats.sessionStart = Date.now();
    this.bindEvents();
  },

  /**
   * Bind UI events
   */
  bindEvents() {
    // Listen button
    document.getElementById('listenBtn')?.addEventListener('click', () => {
      this.playCurrentCard();
    });

    // Listen slow button
    document.getElementById('listenSlowBtn')?.addEventListener('click', () => {
      this.playCurrentCard(0.75);
    });

    // Record button
    document.getElementById('recordBtn')?.addEventListener('click', () => {
      this.toggleRecording();
    });

    // Next button
    document.getElementById('nextBtn')?.addEventListener('click', () => {
      this.nextCard();
    });

    // Previous button
    document.getElementById('prevBtn')?.addEventListener('click', () => {
      this.prevCard();
    });

    // Shuffle button
    document.getElementById('shuffleBtn')?.addEventListener('click', () => {
      this.shuffleCards();
    });
  },

  /**
   * Load flashcards from Google Drive
   */
  async loadCards() {
    try {
      App.showLoading('載入詞彙卡片中...');

      const flashcards = await DriveAPI.getFlashcards();

      if (!flashcards || flashcards.length === 0) {
        App.hideLoading();
        App.showMessage('找不到詞彙卡片。請先在擴充功能中添加一些詞彙！', 'warning');
        return false;
      }

      // Filter cards that have content suitable for speaking practice
      this.cards = flashcards.filter(card => {
        return card.front && card.front.trim().length > 0;
      });

      if (this.cards.length === 0) {
        App.hideLoading();
        App.showMessage('沒有適合口說練習的卡片', 'warning');
        return false;
      }

      // Detect language from first card
      if (this.cards[0].language) {
        this.currentLanguage = this.cards[0].language.toLowerCase();
      }

      this.currentIndex = 0;
      this.displayCurrentCard();

      App.hideLoading();
      App.showMessage(`已載入 ${this.cards.length} 張卡片`, 'success');

      return true;
    } catch (error) {
      console.error('Failed to load cards:', error);
      App.hideLoading();
      App.showMessage('載入卡片失敗: ' + error.message, 'error');
      return false;
    }
  },

  /**
   * Display current card
   */
  displayCurrentCard() {
    const card = this.cards[this.currentIndex];
    if (!card) return;

    // Update card content
    const frontEl = document.getElementById('cardFront');
    const backEl = document.getElementById('cardBack');
    const progressEl = document.getElementById('cardProgress');

    if (frontEl) {
      frontEl.textContent = card.front;
    }

    if (backEl) {
      // Show definition/translation
      const back = card.back || card.definition || '';
      backEl.textContent = back;
    }

    if (progressEl) {
      progressEl.textContent = `${this.currentIndex + 1} / ${this.cards.length}`;
    }

    // Update progress bar
    const progressBar = document.getElementById('progressBar');
    if (progressBar) {
      const progress = ((this.currentIndex + 1) / this.cards.length) * 100;
      progressBar.style.width = `${progress}%`;
    }

    // Reset result area
    this.hideResult();

    // Update navigation buttons
    this.updateNavButtons();
  },

  /**
   * Update navigation button states
   */
  updateNavButtons() {
    const prevBtn = document.getElementById('prevBtn');
    const nextBtn = document.getElementById('nextBtn');

    if (prevBtn) {
      prevBtn.disabled = this.currentIndex === 0;
    }

    if (nextBtn) {
      nextBtn.disabled = this.currentIndex >= this.cards.length - 1;
    }
  },

  /**
   * Go to next card
   */
  nextCard() {
    if (this.currentIndex < this.cards.length - 1) {
      this.currentIndex++;
      this.displayCurrentCard();
    }
  },

  /**
   * Go to previous card
   */
  prevCard() {
    if (this.currentIndex > 0) {
      this.currentIndex--;
      this.displayCurrentCard();
    }
  },

  /**
   * Shuffle cards
   */
  shuffleCards() {
    // Fisher-Yates shuffle
    for (let i = this.cards.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [this.cards[i], this.cards[j]] = [this.cards[j], this.cards[i]];
    }

    this.currentIndex = 0;
    this.displayCurrentCard();
    App.showMessage('已隨機排序卡片', 'info');
  },

  /**
   * Play current card pronunciation
   */
  async playCurrentCard(speed = 1.0) {
    const card = this.cards[this.currentIndex];
    if (!card) return;

    const text = card.front;
    const listenBtn = document.getElementById('listenBtn');
    const listenSlowBtn = document.getElementById('listenSlowBtn');

    // Update button state
    if (listenBtn) {
      listenBtn.disabled = true;
      listenBtn.innerHTML = '<span class="btn-icon">⏳</span> 播放中...';
    }
    if (listenSlowBtn) listenSlowBtn.disabled = true;

    try {
      // Stop any current playback
      this.stopAudio();

      // Try OpenAI TTS first
      if (TTSService.isAvailable()) {
        const langInfo = this.languageMap[this.currentLanguage] || this.languageMap['dutch'];
        const result = await TTSService.textToSpeech(text, null, speed);

        this.currentAudio = new Audio(result.audioUrl);
        this.currentAudio.onended = () => this.resetPlayButton();
        this.currentAudio.onerror = () => this.resetPlayButton();

        await this.currentAudio.play();
      } else {
        // Fallback to browser TTS
        const langInfo = this.languageMap[this.currentLanguage] || this.languageMap['dutch'];
        await TTSService.speakWithBrowser(text, langInfo.ttsLang, speed);
        this.resetPlayButton();
      }
    } catch (error) {
      console.error('TTS error:', error);
      App.showMessage('播放失敗: ' + error.message, 'error');
      this.resetPlayButton();
    }
  },

  /**
   * Reset play button state
   */
  resetPlayButton() {
    const listenBtn = document.getElementById('listenBtn');
    const listenSlowBtn = document.getElementById('listenSlowBtn');

    if (listenBtn) {
      listenBtn.disabled = false;
      listenBtn.innerHTML = '<span class="btn-icon">🔊</span> 聽標準發音';
    }
    if (listenSlowBtn) {
      listenSlowBtn.disabled = false;
    }
  },

  /**
   * Stop current audio playback
   */
  stopAudio() {
    if (this.currentAudio) {
      this.currentAudio.pause();
      this.currentAudio.currentTime = 0;
      this.currentAudio = null;
    }
    speechSynthesis.cancel();
  },

  /**
   * Toggle recording
   */
  async toggleRecording() {
    if (this.isRecording) {
      this.stopRecording();
    } else {
      await this.startRecording();
    }
  },

  /**
   * Start recording
   */
  async startRecording() {
    try {
      // Request microphone permission
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true
        }
      });

      this.audioChunks = [];
      this.mediaRecorder = new MediaRecorder(stream, {
        mimeType: 'audio/webm;codecs=opus'
      });

      this.mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          this.audioChunks.push(event.data);
        }
      };

      this.mediaRecorder.onstop = () => {
        // Stop all tracks
        stream.getTracks().forEach(track => track.stop());

        // Process recording
        this.processRecording();
      };

      this.mediaRecorder.start();
      this.isRecording = true;

      // Update UI
      this.updateRecordingUI(true);

    } catch (error) {
      console.error('Recording error:', error);

      if (error.name === 'NotAllowedError') {
        App.showMessage('請允許使用麥克風權限', 'error');
      } else if (error.name === 'NotFoundError') {
        App.showMessage('找不到麥克風設備', 'error');
      } else {
        App.showMessage('錄音失敗: ' + error.message, 'error');
      }
    }
  },

  /**
   * Stop recording
   */
  stopRecording() {
    if (this.mediaRecorder && this.isRecording) {
      this.mediaRecorder.stop();
      this.isRecording = false;
      this.updateRecordingUI(false);
    }
  },

  /**
   * Update recording UI
   */
  updateRecordingUI(isRecording) {
    const recordBtn = document.getElementById('recordBtn');
    const recordingIndicator = document.getElementById('recordingIndicator');

    if (recordBtn) {
      if (isRecording) {
        recordBtn.innerHTML = '<span class="btn-icon">⏹️</span> 停止錄音';
        recordBtn.classList.add('recording');
      } else {
        recordBtn.innerHTML = '<span class="btn-icon">🎤</span> 開始錄音';
        recordBtn.classList.remove('recording');
      }
    }

    if (recordingIndicator) {
      recordingIndicator.style.display = isRecording ? 'flex' : 'none';
    }
  },

  /**
   * Process recorded audio
   */
  async processRecording() {
    if (this.audioChunks.length === 0) {
      App.showMessage('錄音內容為空', 'warning');
      return;
    }

    const card = this.cards[this.currentIndex];
    const targetText = card.front;

    try {
      App.showLoading('分析發音中...');

      const audioBlob = new Blob(this.audioChunks, { type: 'audio/webm' });

      // Check if OpenAI is available
      if (!TTSService.isAvailable()) {
        App.hideLoading();
        this.showSimpleResult(targetText, audioBlob);
        return;
      }

      // Transcribe using Whisper
      const langInfo = this.languageMap[this.currentLanguage] || this.languageMap['dutch'];
      const transcription = await TTSService.transcribeAudio(audioBlob, langInfo.code);

      console.log('Transcription:', transcription);

      // Evaluate pronunciation
      const evaluation = await TTSService.evaluatePronunciation(
        targetText,
        transcription.text,
        this.currentLanguage
      );

      App.hideLoading();

      // Show result
      this.showResult(targetText, transcription.text, evaluation, audioBlob);

      // Update statistics
      this.stats.practiced++;
      this.stats.totalScore += evaluation.accuracy;

    } catch (error) {
      console.error('Processing error:', error);
      App.hideLoading();
      App.showMessage('分析失敗: ' + error.message, 'error');
    }
  },

  /**
   * Show pronunciation result
   */
  showResult(targetText, spokenText, evaluation, audioBlob) {
    const resultArea = document.getElementById('resultArea');
    if (!resultArea) return;

    // Determine score color
    let scoreClass = 'score-low';
    if (evaluation.accuracy >= 80) {
      scoreClass = 'score-high';
    } else if (evaluation.accuracy >= 60) {
      scoreClass = 'score-medium';
    }

    // Build issues HTML
    let issuesHtml = '';
    if (evaluation.issues && evaluation.issues.length > 0) {
      issuesHtml = `
        <div class="result-issues">
          <strong>需要改進：</strong>
          <ul>
            ${evaluation.issues.map(issue => `<li>${issue}</li>`).join('')}
          </ul>
        </div>
      `;
    }

    // Build tips HTML
    let tipsHtml = '';
    if (evaluation.tips && evaluation.tips.length > 0) {
      tipsHtml = `
        <div class="result-tips">
          <strong>學習建議：</strong>
          <ul>
            ${evaluation.tips.map(tip => `<li>${tip}</li>`).join('')}
          </ul>
        </div>
      `;
    }

    resultArea.innerHTML = `
      <div class="result-card">
        <div class="result-score ${scoreClass}">
          <span class="score-number">${Math.round(evaluation.accuracy)}</span>
          <span class="score-label">分</span>
        </div>

        <div class="result-comparison">
          <div class="comparison-item">
            <label>目標：</label>
            <span class="target-text">${targetText}</span>
          </div>
          <div class="comparison-item">
            <label>你說：</label>
            <span class="spoken-text">${spokenText || '（無法識別）'}</span>
          </div>
        </div>

        <div class="result-feedback">
          ${evaluation.feedback}
        </div>

        ${issuesHtml}
        ${tipsHtml}

        <div class="result-encouragement">
          ${evaluation.encouragement}
        </div>

        <div class="result-actions">
          <button class="btn btn-secondary" onclick="SpeakingPractice.playRecording()">
            <span class="btn-icon">🔈</span> 播放錄音
          </button>
          <button class="btn btn-primary" onclick="SpeakingPractice.retryPractice()">
            <span class="btn-icon">🔄</span> 再試一次
          </button>
        </div>
      </div>
    `;

    resultArea.style.display = 'block';

    // Save audio blob for playback
    this.lastRecording = audioBlob;
  },

  /**
   * Show simple result (without AI evaluation)
   */
  showSimpleResult(targetText, audioBlob) {
    const resultArea = document.getElementById('resultArea');
    if (!resultArea) return;

    resultArea.innerHTML = `
      <div class="result-card">
        <div class="result-info">
          <p>🎤 錄音完成！</p>
          <p class="hint">設定 OpenAI API Key 可獲得 AI 發音評估</p>
        </div>

        <div class="result-comparison">
          <div class="comparison-item">
            <label>目標：</label>
            <span class="target-text">${targetText}</span>
          </div>
        </div>

        <div class="result-actions">
          <button class="btn btn-secondary" onclick="SpeakingPractice.playRecording()">
            <span class="btn-icon">🔈</span> 播放錄音
          </button>
          <button class="btn btn-primary" onclick="SpeakingPractice.retryPractice()">
            <span class="btn-icon">🔄</span> 再試一次
          </button>
        </div>
      </div>
    `;

    resultArea.style.display = 'block';
    this.lastRecording = audioBlob;
  },

  /**
   * Hide result area
   */
  hideResult() {
    const resultArea = document.getElementById('resultArea');
    if (resultArea) {
      resultArea.style.display = 'none';
    }
  },

  /**
   * Play last recording
   */
  playRecording() {
    if (!this.lastRecording) return;

    const audioUrl = URL.createObjectURL(this.lastRecording);
    const audio = new Audio(audioUrl);
    audio.play();
  },

  /**
   * Retry practice for current card
   */
  retryPractice() {
    this.hideResult();
  },

  /**
   * Save session statistics
   */
  async saveSessionStats() {
    if (this.stats.practiced === 0) return;

    const avgScore = this.stats.totalScore / this.stats.practiced;

    try {
      await DriveAPI.updateSpeakingStats({
        cardsCount: this.stats.practiced,
        score: avgScore,
        duration: Date.now() - this.stats.sessionStart
      });

      console.log('Session stats saved');
    } catch (error) {
      console.error('Failed to save stats:', error);
    }
  },

  /**
   * Get session summary
   */
  getSessionSummary() {
    const avgScore = this.stats.practiced > 0
      ? Math.round(this.stats.totalScore / this.stats.practiced)
      : 0;

    return {
      practiced: this.stats.practiced,
      avgScore: avgScore,
      duration: Date.now() - this.stats.sessionStart
    };
  }
};

// Export for use
window.SpeakingPractice = SpeakingPractice;
